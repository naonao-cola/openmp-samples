# OpenMP Examples Document

This is the OpenMP Examples document in LaTeX format.

Please see [Contributions.md](Contributions.md) on how to make contributions to adding new examples.

For a brief revision history, please see [Changes.log](Changes.log).

For copyright information, please see [omp_copyright.txt](omp_copyright.txt).

